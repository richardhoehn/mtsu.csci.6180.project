# Server Details


## Database
We should use the TinyDB built for Python. It can be installed by `pip(3) install tinydb`. 

Once installed we can access the dat and share it via  `db.json` file in the `./database/` folder.

# App Icon
We used the following service: `https://easyappicon.com/`



